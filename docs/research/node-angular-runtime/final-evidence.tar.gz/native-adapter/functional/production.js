export function choose(value) {
    if (value > 0) {
        return value + 1;
    }
    return value - 1;
}
//# sourceMappingURL=production.js.map