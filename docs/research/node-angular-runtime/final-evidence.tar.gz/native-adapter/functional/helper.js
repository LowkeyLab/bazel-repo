export function twice(value) {
    return value * 2;
}
//# sourceMappingURL=helper.js.map