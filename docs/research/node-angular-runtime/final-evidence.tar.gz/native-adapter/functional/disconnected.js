export function neverCalled(value) {
    if (value > 0) {
        return value + 10;
    }
    return value - 10;
}
//# sourceMappingURL=disconnected.js.map