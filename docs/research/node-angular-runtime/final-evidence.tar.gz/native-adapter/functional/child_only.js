export function childOnly() {
    return 41;
}
//# sourceMappingURL=child_only.js.map