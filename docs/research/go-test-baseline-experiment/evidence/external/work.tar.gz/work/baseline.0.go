//line docs/research/go-test-baseline-experiment/external_test.go:1:1
package baseline_test

func externalUnused() int {GoBaselineCover_0[0] = 1 ; GoBaselineCover_0[1] = GoBaselineCoverP ; GoBaselineCover_0[2] = 0 ; GoBaselineCover_0[3] = 1;
	return 9
}
