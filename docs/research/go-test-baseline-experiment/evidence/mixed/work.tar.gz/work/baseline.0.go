//line docs/research/go-test-baseline-experiment/internal_test.go:1:1
package baseline

func internalUnused() int {GoBaselineCover_0[0] = 1 ; GoBaselineCover_0[1] = GoBaselineCoverP ; GoBaselineCover_0[2] = 0 ; GoBaselineCover_0[3] = 1;
	return 7
}
