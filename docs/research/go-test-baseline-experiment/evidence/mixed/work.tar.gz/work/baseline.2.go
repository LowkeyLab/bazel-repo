//line docs/research/go-test-baseline-experiment/declarations.go:1:1
package baseline

type Declared struct{ Value int }

const Value = 3
