//line docs/research/go-test-baseline-experiment/external_test.go:1:1
package baseline_test

func externalUnused() int {GoBaselineCover_1[0] = 1 ; GoBaselineCover_1[1] = GoBaselineCoverP ; GoBaselineCover_1[2] = 1 ; GoBaselineCover_1[3] = 1;
	return 9
}
