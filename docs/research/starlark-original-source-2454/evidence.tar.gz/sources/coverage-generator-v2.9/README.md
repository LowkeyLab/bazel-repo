This coverage_output_generator version was built from the Bazel repository
at commit hash d49967e8cf23b2f1179eba168766e93afb736c6b using Bazel version 8.3.0.
To build the same zip from source, run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout d49967e8cf23b2f1179eba168766e93afb736c6b
$ bazel build -c opt //tools/test/CoverageOutputGenerator/java/com/google/devtools/coverageoutputgenerator:coverage_output_generator.zip
