# Artifact scope

The coverage-outputs group contains native profiles from the native coverage command.
The final-test-outputs group contains the final test logs and requested semantic outputs.
It omits stale coverage-directory files from the earlier coverage command.
The archive omits Bazel binary cache metadata.
Private originals retain that metadata and all earlier files.
The test logs preserve fresh versus cached execution evidence.
