"""Validate the preserved bounded SQL reports without database execution."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent

def records(path):
    result = {}
    source = None
    for line in path.read_text().splitlines():
        if line.startswith('SF:'):
            source = line[3:]
            assert source not in result
            result[source] = {'DA': {}, 'BRDA': {}}
        elif line.startswith('DA:'):
            location, count = line[3:].split(',')
            result[source]['DA'][int(location)] = int(count)
        elif line.startswith('BRDA:'):
            location, block, arm, count = line[5:].split(',')
            result[source]['BRDA'][tuple(map(int, (location, block, arm)))] = int(count)
    return result

expected = records(root / 'export-valid-final/baseline.dat')
assert len(expected) == 5
assert sum(len(value['DA']) for value in expected.values()) == 35
assert all(count == 0 for value in expected.values() for count in value['DA'].values())
for application in ['application_a', 'application_b']:
    observed = records(root / 'export-valid-final' / f'{application}.dat')
    assert observed.keys() == expected.keys()
    for source, value in observed.items():
        assert value['DA'].keys() == expected[source]['DA'].keys()
        for kind in ['DA', 'BRDA']:
            for key, count in value[kind].items():
                expected[source][kind][key] += count
for order in ['ab', 'ba']:
    path = root / f'merged-{order}.dat'
    assert path.stat().st_size > 0
    assert records(path) == expected
assert (root / 'merged-ab.dat').read_bytes() == (root / 'merged-ba.dat').read_bytes()
assert sum(count > 0 for value in expected.values() for count in value['DA'].values()) == 9
assert all(count in (0, 2) for value in expected.values() for count in value['DA'].values())
for case, status in [('valid-final', 0), ('missing', 1), ('empty', 1), ('corrupt', 1), ('partial', 1), ('historical-metadata', 1)]:
    assert int((root / f'export-{case}.exit').read_text()) == status
    if status:
        assert not (root / f'export-{case}/summary.json').exists()
for path in (root / 'export-valid-final').iterdir():
    assert path.read_bytes() == (root / 'export-final-source' / path.name).read_bytes()
print(json.dumps({'result': 'passed', 'sources': 5, 'lines': 35, 'positive_lines': 9, 'branches': 2, 'sha256': hashlib.sha256((root / 'merged-ab.dat').read_bytes()).hexdigest()}))
