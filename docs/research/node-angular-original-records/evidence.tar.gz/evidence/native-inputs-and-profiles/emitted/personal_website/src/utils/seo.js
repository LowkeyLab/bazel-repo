export function canonicalUrl(path, site) {
    const url = new URL(path, site);
    url.search = "";
    url.hash = "";
    if (!url.pathname.endsWith(".xml") && !url.pathname.endsWith("/"))
        url.pathname += "/";
    return url.href;
}
export function escapeXml(value) {
    return value
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&apos;");
}
//# sourceMappingURL=seo.js.map