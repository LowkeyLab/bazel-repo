export function publishedPosts(posts) {
    return posts
        .filter((post) => !post.data.draft)
        .sort((a, b) => b.data.publishDate.valueOf() - a.data.publishDate.valueOf() ||
        a.id.localeCompare(b.id));
}
export function homePosts(posts) {
    const published = publishedPosts(posts);
    return {
        featured: published.filter((post) => post.data.featured).slice(0, 3),
        recent: published.filter((post) => !post.data.featured).slice(0, 3),
    };
}
export function calculateReadingTime(content) {
    const words = content.split(/\s+/).length;
    return Math.ceil(words / 200);
}
//# sourceMappingURL=blog.js.map