(builtins.trace "NIXCOV:disconnected.nix:7" if (builtins.trace "NIXCOV:disconnected.nix:0" false) then
  (builtins.trace "NIXCOV:disconnected.nix:3" (builtins.trace "NIXCOV:disconnected.nix:1" 8) + (builtins.trace "NIXCOV:disconnected.nix:2" 1))
else
  (builtins.trace "NIXCOV:disconnected.nix:6" (builtins.trace "NIXCOV:disconnected.nix:4" 9) + (builtins.trace "NIXCOV:disconnected.nix:5" 1)))
