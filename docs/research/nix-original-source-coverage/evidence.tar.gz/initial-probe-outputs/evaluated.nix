(builtins.trace "NIXCOV:evaluated.nix:17" let
  forced =
    (builtins.trace "NIXCOV:evaluated.nix:7" if (builtins.trace "NIXCOV:evaluated.nix:0" true) then
      (builtins.trace "NIXCOV:evaluated.nix:3" (builtins.trace "NIXCOV:evaluated.nix:1" 1) + (builtins.trace "NIXCOV:evaluated.nix:2" 2))
    else
      (builtins.trace "NIXCOV:evaluated.nix:6" (builtins.trace "NIXCOV:evaluated.nix:4" throw) (builtins.trace "NIXCOV:evaluated.nix:5" "untaken")));
  lazy =
    (builtins.trace "NIXCOV:evaluated.nix:10" (builtins.trace "NIXCOV:evaluated.nix:8" throw) (builtins.trace "NIXCOV:evaluated.nix:9" "must stay lazy"));
  builder = (builtins.trace "NIXCOV:evaluated.nix:11" ''
    printf '%s\n' builder-ran > "$out"
    if false; then
      printf '%s\n' untaken >> "$out"
    fi
  '');
in
(builtins.trace "NIXCOV:evaluated.nix:16" {
  result = (builtins.trace "NIXCOV:evaluated.nix:14" (builtins.trace "NIXCOV:evaluated.nix:12" forced) + (builtins.trace "NIXCOV:evaluated.nix:13" forced));
  script = (builtins.trace "NIXCOV:evaluated.nix:15" builder);
}))
