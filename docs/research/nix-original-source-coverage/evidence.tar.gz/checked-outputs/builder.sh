printf '%s\n' builder-ran > "$out"
if false; then
  printf '%s\n' untaken >> "$out"
fi
