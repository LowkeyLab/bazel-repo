import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('<RECEIPTS>')
evidence=root/'evidence'
flags=['--jobs=4','--local_resources=cpu=2','--local_resources=memory=2048','--bes_backend=','--remote_cache=','--remote_executor=','--noremote_upload_local_results']
exporter='//predix/internal/research_sql/export_tool:export_profile'
controls=[('missing-body','after-body-profile.json','missing'),('empty-body','after-body-profile.json','empty'),('corrupt-body','after-body-profile.json','corrupt'),('partial-body','after-body-profile.json','partial'),('wrong-body-hash','application_a-body-profile.json','hash'),('decreased-body','application_b-body-profile.json','decrease'),('missing-rust-call','application_a-rust-call.json','missing'),('missing-rust-witness','database.log','witness'),('missing-receipts','after-receipts.json','missing'),('missing-native','application_a-profiler-statements.json','missing')]
results=[]
for name,filename,change in controls:
    directory=evidence/'faults'/name
    shutil.copytree(evidence/'native',directory,copy_function=shutil.copyfile)
    directory.chmod(0o700)
    path=directory/filename
    if change=='missing':path.unlink()
    elif change=='empty':path.write_text('[]')
    elif change=='corrupt':path.write_text('{')
    elif change=='witness':path.write_text('\n'.join(line for line in path.read_text().splitlines() if 'coverage_research_rust' not in line))
    else:
        data=json.loads(path.read_text())
        if change=='partial':data.pop()
        elif change=='hash':data[0]['source_sha']='invalid'
        elif change=='decrease':next(row for row in data if row['hits']>0)['hits']=-1
        path.write_text(json.dumps(data))
    command=['bazel','--host_jvm_args=-Xmx1536m','run',exporter]+flags+['--','--evidence',str(directory),'--output',str(directory/'export')]
    with (directory/'export-command.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    same=(directory/'functional.json').read_bytes()==(evidence/'native/functional.json').read_bytes()
    results.append({'control':name,'exit':result.returncode,'functional_record_unchanged':same,'success_summary_present':(directory/'export/summary.json').exists()})
    if result.returncode!=1 or not same or (directory/'export/summary.json').exists():raise ValueError('Fault control did not reject: '+name)
(evidence/'fault-controls.json').write_text(json.dumps(results,indent=2)+'\n')
for order,names in [('ab',['baseline','application_a','application_b']),('ba',['application_b','application_a','baseline'])]:
    directory=evidence/('merge-'+order)
    directory.mkdir()
    for i,name in enumerate(names):shutil.copyfile(evidence/'export'/(name+'.dat'),directory/(str(i+1)+'.dat'))
    command=['bazel','--host_jvm_args=-Xmx1536m','run','@bazel_tools//tools/test/CoverageOutputGenerator/java/com/google/devtools/coverageoutputgenerator:Main']+flags+['--','--coverage_dir='+str(directory),'--output_file='+str(evidence/('merged-'+order+'.dat'))]
    with (evidence/('merge-'+order+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise ValueError('Merge failed')
print(json.dumps({'faults_rejected':len(results),'merge_orders':2}))
