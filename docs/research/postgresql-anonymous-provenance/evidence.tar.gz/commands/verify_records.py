"""Compare LCOV records with independently authored original source locations."""
import hashlib
import json
import sys
from pathlib import Path
root=Path(sys.argv[1])
prefix='predix/internal/research_sql/'
expected={
'prediction_bot/migrations/002_application_login.sql':{2:1,3:1,4:1,10:1},
'nicknamer2/src/discord_server/repo/lib.rs':{136:1},
prefix+'disconnected.sql':{2:0},
prefix+'disconnected_body.sql':{2:0,3:0,4:0},
prefix+'helper_body.sql':{2:1,3:1,4:1,5:0,7:1},
prefix+'profile_control.sql':{5:1,6:1,7:1,9:0},
prefix+'statements.sql':{2:1,7:1,11:1,15:1,16:1,17:1,18:0,21:1,27:0},
prefix+'test_body.sql':{2:1,3:1,4:1,5:1,6:0,8:1},
'predix/internal/sql/query.sql':dict.fromkeys((2,7,11,15,20,24,27,31,35,40,46,53,57,62,66,71,75,79,84,90,94,100,105,110),0),
}
expected['predix/internal/sql/query.sql'][11]=1
branches={prefix+'helper_body.sql':{'4,4,0':0,'4,4,1':1},prefix+'profile_control.sql':{'6,2,0':1,'6,2,1':0},prefix+'statements.sql':{'17,17,0':0,'17,17,1':1},prefix+'test_body.sql':{'5,5,0':0,'5,5,1':1}}
def parse(path):
    lines={}; arms={}; source=None
    for row in path.read_text().splitlines():
        if row.startswith('SF:'):
            source=row[3:]
            if source in lines: raise ValueError('Duplicate source identity')
            lines[source]={}
        elif row.startswith('DA:'):
            line,count=map(int,row[3:].split(',')[:2])
            if line in lines[source]: raise ValueError('Duplicate original line')
            lines[source][line]=count
        elif row.startswith('BRDA:'):
            *identity,count=row[5:].split(',')
            key=','.join(identity)
            if key in arms.setdefault(source,{}): raise ValueError('Duplicate branch identity')
            arms[source][key]=int(count)
    return lines,arms
for name,multiplier in [('baseline.dat',0),('application_a.dat',1),('application_b.dat',1),('merged-ab.dat',2),('merged-ba.dat',2)]:
    path=root/name if name.startswith('merged') else root/'export'/name
    actual,actual_arms=parse(path)
    wanted={source:{line:count*multiplier for line,count in values.items()} for source,values in expected.items()}
    wanted_arms={source:{key:count*multiplier for key,count in values.items()} for source,values in branches.items()}
    if actual!=wanted or actual_arms!=wanted_arms: raise ValueError(f'Original records differ: {name}')
if (root/'merged-ab.dat').read_bytes()!=(root/'merged-ba.dat').read_bytes(): raise ValueError('Merge order changed bytes')
summary={'sources':len(expected),'original_lines':sum(map(len,expected.values())),'positive_lines':sum(count>0 for values in expected.values() for count in values.values()),'branches':sum(map(len,branches.values())),'positive_branches':sum(count>0 for values in branches.values() for count in values.values()),'merged_sha256':hashlib.sha256((root/'merged-ab.dat').read_bytes()).hexdigest(),'every_original_record_matches':True,'merge_orders_byte_identical':True}
(root/'expected-records.json').write_text(json.dumps({'per_application_lines':expected,'per_application_branches':branches},indent=2)+'\n')
(root/'record-check.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
