(ns coverage-research.runner
  (:require [clojure.data.json :as json]
            [clojure.java.io :as io]
            [clojure.string :as str]
            [clojure.test :as test]
            [cloverage.coverage :as coverage]
            [cloverage.report :as report]
            [cloverage.report.lcov :as lcov]
            [cloverage.source :as source])
  (:import [java.lang ProcessHandle]
           [java.security MessageDigest]
           [java.util.concurrent TimeUnit]
           [java.util.concurrent.atomic AtomicInteger]))

(def sources
  (array-map
   'lowkeylab.clojure-sample.core "clojure_sample/src/lowkeylab/clojure_sample/core.clj"
   'coverage-research.production "clojure_sample/research/src/coverage_research/production.clj"
   'coverage-research.helper "clojure_sample/research/src/coverage_research/helper.clj"
   'coverage-research.disconnected "clojure_sample/research/src/coverage_research/disconnected.clj"
   'coverage-research.child "clojure_sample/research/src/coverage_research/child.clj"
   'lowkeylab.clojure-sample.core-test "clojure_sample/test/lowkeylab/clojure_sample/core_test.clj"
   'coverage-research.cases-test "clojure_sample/research/src/coverage_research/cases_test.clj"))

(defn save-json [file value]
  (spit file (json/write-str value :escape-slash false)))

(defn sha256 [text]
  (format "%064x" (BigInteger. 1 (.digest (MessageDigest/getInstance "SHA-256") (.getBytes text "UTF-8")))))

(defn check [condition message]
  (when-not condition (throw (ex-info message {}))))

(defn reset-hits []
  (doseq [form @coverage/*covered*]
    (.set ^AtomicInteger (:hits form) 0)))

(defn snapshot [directory stage mapping]
  (let [forms (coverage/covered)
        expanded (vec (report/gather-stats forms))
        records (mapv (fn [idx form]
                        {:index idx :file (:file form)
                         :canonicalFile (get mapping (:file form))
                         :line (:line form) :lib (str (:lib form))
                         :tracked (:tracked form) :hits (:hits form) :covered (:covered form)
                         :form (binding [*print-meta* true] (pr-str (:form form)))
                         :fullForm (binding [*print-meta* true] (pr-str (:full-form form)))})
                      (range) forms)]
    (check (every? :canonicalFile records) "A tracked form has no canonical source identity.")
    (save-json (io/file directory (str stage ".forms.json")) records)
    (spit (io/file directory (str stage ".forms.edn"))
          (binding [*print-meta* true] (pr-str forms)))
    (spit (io/file directory (str stage ".raw.lcov"))
          (with-out-str (lcov/write-lcov-report expanded)))
    (spit (io/file directory (str stage ".lcov"))
          (with-redefs [source/source-file-path
                        (fn [resource]
                          (or (get mapping resource)
                              (throw (ex-info "An exported source has no canonical identity." {:resource resource}))))]
            (with-out-str (lcov/write-lcov-report expanded))))
    records))

(defn lines [text]
  (check (seq text) "The LCOV artifact is empty.")
  (reduce (fn [{:keys [file] :as state} line]
            (cond
              (str/starts-with? line "SF:") (assoc state :file (subs line 3))
              (str/starts-with? line "DA:")
              (let [[_ n hits] (re-matches #"DA:([0-9]+),([0-9]+)" line)]
                (check (and file n hits) "An LCOV line record is invalid.")
                (assoc-in state [:records file (Long/parseLong n)] (Long/parseLong hits)))
              (or (str/starts-with? line "TN:") (str/starts-with? line "LF:")
                  (str/starts-with? line "LH:") (= line "end_of_record") (str/blank? line)) state
              :else (throw (ex-info "An LCOV record is invalid." {:line line}))))
          {:records {}} (str/split-lines text)))

(defn hit [records file line]
  (get-in records [:records file line] 0))

(defn run-child [mode directory]
  (.mkdirs (io/file directory))
  (let [java (str (System/getProperty "java.home") "/bin/java")
        command [java "-Xmx512m" "-cp" (System/getProperty "java.class.path")
                 "clojure.main" "-m" "coverage-research.runner" mode (str directory)]
        builder (ProcessBuilder. ^java.util.List command)
        _ (.redirectOutput builder (io/file directory "stdout.txt"))
        _ (.redirectError builder (io/file directory "stderr.txt"))
        process (.start builder)
        completed (.waitFor process 60 TimeUnit/SECONDS)]
    (when-not completed (.destroyForcibly process))
    (check completed "The child JVM did not complete within the bounded timeout.")
    (let [exit (.exitValue process)
          record {:mode mode :pid (.pid process) :parentPid (.pid (ProcessHandle/current))
                  :completed completed :exitStatus exit :command command}]
      (save-json (io/file directory "completion.json") record)
      (check (zero? exit) "The child JVM returned a failure status.")
      record)))

(defn validate-output [directory expected-mode expected-pid expected-sources]
  (let [receipt-file (io/file directory "receipt.json")
        lcov-file (io/file directory "measured.lcov")]
    (check (.isFile receipt-file) "The process receipt is missing.")
    (check (.isFile lcov-file) "The process LCOV artifact is missing.")
    (let [receipt (json/read-str (slurp receipt-file) :key-fn keyword)
          data (lines (slurp lcov-file))]
      (check (= expected-mode (:mode receipt)) "The process mode does not match its receipt.")
      (check (= expected-pid (:pid receipt)) "The process identity does not match its completion record.")
      (check (= expected-sources (:sources receipt)) "The source hashes do not match the parent inventory.")
      (check (= (set (vals sources)) (set (keys (:records data)))) "An expected source has no executable records.")
      (doseq [namespace ['coverage-research.disconnected 'coverage-research.child]]
        (check (contains? (get-in data [:records (sources namespace)]) 4) "An expected executable body line is missing."))
      (if (= expected-mode "baseline")
        (check (every? zero? (mapcat vals (vals (:records data)))) "The baseline contains a measured hit.")
        (check (pos? (hit data (sources 'coverage-research.child) 4)) "The child-only original line has no positive record."))
      data)))

(defn rejected? [f]
  (try (f) false (catch Throwable _ true)))

(defn -main [mode directory]
  (.mkdirs (io/file directory))
  (binding [coverage/*covered* (atom [])]
    (check (not (find-ns 'lowkeylab.clojure-sample.core)) "The maintained AOT namespace loaded before instrumentation.")
    (check (not (find-ns 'coverage-research.production)) "The research AOT namespace loaded before instrumentation.")
    (let [aot-resources ["lowkeylab/clojure_sample/core__init.class" "coverage_research/production__init.class"]
          _ (check (every? io/resource aot-resources) "An expected AOT class is absent from the runtime.")
          mapping (into {} (map (fn [[namespace path]] [(source/resource-path namespace) path]) sources))
          hashes (mapv (fn [[namespace path]]
                         {:path path :sha256 (sha256 (slurp (io/resource (source/resource-path namespace))))}) sources)]
      (doseq [[namespace path] sources]
        (let [file (io/file directory "sources" path)]
          (.mkdirs (.getParentFile file))
          (spit file (slurp (io/resource (source/resource-path namespace))))))
      (coverage/instrument-namespaces {} (keys sources))
      (let [initialization (snapshot directory "initialization" mapping)
            _ (reset-hits)
            baseline (snapshot directory "baseline" mapping)
            _ (check (every? #(zero? (:hits %)) baseline) "The baseline contains initialization hits.")
            result (case mode
                     "baseline" {:noMeasuredCalls true}
                     "child" {:childValue ((requiring-resolve 'coverage-research.child/execute))}
                     "parent" (test/run-tests 'lowkeylab.clojure-sample.core-test 'coverage-research.cases-test)
                     (throw (ex-info "The research mode is invalid." {:mode mode})))
            measured (snapshot directory "measured" mapping)
            data (lines (slurp (io/file directory "measured.lcov")))]
        (when (= mode "parent")
          (check (and (zero? (:fail result)) (zero? (:error result))) "A functional Clojure test failed.")
          (doseq [[path line] [[(sources 'lowkeylab.clojure-sample.core) 7]
                             [(sources 'lowkeylab.clojure-sample.core-test) 6]
                             [(sources 'coverage-research.production) 10]
                             [(sources 'coverage-research.production) 11]
                             [(sources 'coverage-research.helper) 4]
                             [(sources 'coverage-research.cases-test) 7]]]
            (check (pos? (hit data path line)) (str "An expected original line has no positive record: " path ":" line)))
          (check (contains? (get-in data [:records (sources 'coverage-research.disconnected)]) 4) "The disconnected body has no executable record.")
          (check (contains? (get-in data [:records (sources 'coverage-research.child)]) 4) "The child-only body has no executable record.")
          (check (zero? (hit data (sources 'coverage-research.disconnected) 4)) "The disconnected function executed.")
          (check (zero? (hit data (sources 'coverage-research.child) 4)) "The child-only function executed in the parent."))
        (when (= mode "child") (check (= 42 (:childValue result)) "The child result is wrong."))
        (save-json (io/file directory "receipt.json")
                   {:mode mode :pid (.pid (ProcessHandle/current)) :javaVersion (System/getProperty "java.version")
                    :clojureVersion (clojure-version) :aotClassesPresent aot-resources :sources hashes
                    :initializationMarker @(var-get (requiring-resolve 'coverage-research.production/initialization-marker))
                    :initializationPositiveForms (count (filter :covered initialization))
                    :baselinePositiveForms (count (filter :covered baseline))
                    :measuredPositiveForms (count (filter :covered measured)) :functionalResult result})
        (when (= mode "parent")
          (let [baseline-directory (io/file directory "baseline-process")
                child-directory (io/file directory "child-process")
                baseline-completion (run-child "baseline" baseline-directory)
                child-completion (run-child "child" child-directory)
                baseline-data (validate-output baseline-directory "baseline" (:pid baseline-completion) hashes)
                child-data (validate-output child-directory "child" (:pid child-completion) hashes)
                missing-directory (io/file directory "missing-control")
                corrupt-directory (io/file directory "corrupt-control")]
            (.mkdirs missing-directory)
            (.mkdirs corrupt-directory)
            (spit (io/file missing-directory "receipt.json") (slurp (io/file child-directory "receipt.json")))
            (spit (io/file corrupt-directory "receipt.json") (slurp (io/file child-directory "receipt.json")))
            (spit (io/file corrupt-directory "measured.lcov") "corrupt\n")
            (check (rejected? #(validate-output missing-directory "child" (:pid child-completion) hashes)) "Missing child output passed collection validation.")
            (check (rejected? #(validate-output corrupt-directory "child" (:pid child-completion) hashes)) "Corrupt child output passed collection validation.")
            (save-json (io/file directory "capabilities.json")
                       {:parentFunctionalResult result :childValue 42 :baselineValid true
                        :missingChildRejected true :corruptChildRejected true
                        :parentPid (.pid (ProcessHandle/current)) :childPid (:pid child-completion)
                        :baselinePid (:pid baseline-completion) :canonicalSources (vec (vals sources))
                        :disconnectedBodyHits (hit data (sources 'coverage-research.disconnected) 4)
                        :parentChildOnlyHits (hit data (sources 'coverage-research.child) 4)
                        :childOnlyHits (hit child-data (sources 'coverage-research.child) 4)
                        :baselineMeasuredHits (reduce + (mapcat vals (vals (:records baseline-data))))}))))))
)
