# Artifact scope

remote-inputs contains the fresh checksum-pinned action's declared artifacts.
Its process exits 0 while the original-location validator remains false.
local-first contains the earlier fatal location reproduction.
source-before-nonfatal preserves that harness and its dependency declarations.
runtime-sources preserves the successful action's source snapshot before formatting.
formatted-inputs preserves the final source configuration.
The source manifest identifies each snapshot by byte hash.
The maintained sources remain unchanged from the recorded repository base.
Setup failures remain separate command logs.
Initialization profiles remain separate from measured LCOV.
The archive preserves raw forms before LCOV conversion.
Text logs replace private prefixes with documented placeholders.
Binary AOT class resources retain their original captured bytes and hashes.
Private raw originals remain intact.
